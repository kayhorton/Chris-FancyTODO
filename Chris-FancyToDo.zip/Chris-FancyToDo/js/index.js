function TodoController ($scope) {
	$scope.appTitle = "Weight Mapping App";
	$scope.appHeadline = "Enter your weight for today.";
	$scope.saved = localStorage.getItem('todos');
	$scope.todos = (localStorage.getItem('todos')!==null) ? JSON.parse($scope.saved) : [ {text: 'Nothing Found', done: false}, 
	                                                                                     {text: 'Nothing Found2', done: false} ];
	localStorage.setItem('todos', JSON.stringify($scope.todos));

	<!-- (1) add the new item to the collection of items -->
	$scope.addTodo = function() {
		$scope.todos.push({
			text: $scope.todoName+' '+$scope.todoWeight+ ' lbs',
			done: false
		});
		$scope.todoName = ''; //clear the input after adding
		$scope.todoWeight = ''; //clear the input after adding
		localStorage.setItem('todos', JSON.stringify($scope.todos));
	};
	<!-- (2) return a count of undone items -->
	$scope.remaining = function() {
		var count = 0;
		angular.forEach($scope.todos, function(todo){
			count+= todo.done ? 0 : 1;
		});
		return count;
	};
	<!-- (3) delete done entries -->
	$scope.archive = function() {
		var oldTodos = $scope.todos;
		$scope.todos = [];
		angular.forEach(oldTodos, function(todo){
			if (!todo.done)
				$scope.todos.push(todo);
		});
		localStorage.setItem('todos', JSON.stringify($scope.todos));
	};
}